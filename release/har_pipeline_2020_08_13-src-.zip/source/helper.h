#ifndef HELPER_H
#define HELPER_H

#include <QString>

bool isFileInPath(QString fileName, QString &fileNameWithPath);
QString addFileExtensionWindows(QString fileName);

#endif // HELPER_H
